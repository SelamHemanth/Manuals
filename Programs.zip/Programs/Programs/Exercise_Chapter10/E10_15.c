/*E10.15*/
#include<stdio.h>
int main(void)
{
	char x[]="Shilpee";  
	char y[20];
	y="Anjali";
	printf("%s %s\n",x,y);	
	return 0;
}