/*P13.1 Program to show macro expansion*/
#include<stdio.h>
#define MSSG "I understand the use of #define\n"
int main(void)
{
	printf(MSSG);
	return 0;
}