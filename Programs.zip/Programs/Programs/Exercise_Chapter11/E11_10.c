/*E11_10*/
#include<stdio.h>
int main(void)
{
	typedef short int s_int;
	unsigned s_int var=3;
	printf("%u", var);
	return 0;
}