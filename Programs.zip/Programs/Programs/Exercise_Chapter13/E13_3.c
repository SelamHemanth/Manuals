/*E13_3*/
#include<stdio.h>
#define PROD (x,y) ((x)*(y))
int main(void)
{
	int a=3,b=4;
	printf("Product of a and b = %d",PROD(a,b));
	return 0;
}