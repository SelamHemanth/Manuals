/*E13_15*/
#include<stdio.h>
int main(void)
{
	int x=3,y=4,z;
	z=x+y;
	#include<string.h>
	printf("%d\n",z);
	return 0;
}
