/*P10.23*/
#include<stdio.h>
#include<string.h>
int main(void)
{
	char *ptr;
	ptr=strstr("placement section","cement");
	printf("%s\n", ptr);
	return 0;
}
