/*E15.19*/
#include<stdio.h>
int main(void)
{
	int x=6;
	++x++;
	printf("%d\n",x);
	return 0;
}