/*E15.2*/
#include<stdio.h>
enum day{sun=1,mon,tue,wed};
int main(void)
{	
	enum day d1;
	printf("%d\t",mon);
	d1 = mon+2;
	printf("%d\n",d1);
	return 0;
}