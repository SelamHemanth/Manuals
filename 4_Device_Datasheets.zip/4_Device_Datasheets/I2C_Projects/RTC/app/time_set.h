void show_menu(void);
void show_choice(void);
int get_time_date(struct rtc_time *rtc_tm);
